create view "All Categories"(category_display_name, subcategory_display_name) as
SELECT c.displayname  AS category_display_name,
       sc.displayname AS subcategory_display_name
FROM categories c
         JOIN subcategories sc ON c.categoryid = sc.categoryid;

alter table "All Categories"
    owner to "default";

